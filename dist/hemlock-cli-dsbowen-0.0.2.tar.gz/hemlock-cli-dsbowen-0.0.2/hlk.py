from hemlock_cli import hlk

if __name__ == '__main__':
    hlk()